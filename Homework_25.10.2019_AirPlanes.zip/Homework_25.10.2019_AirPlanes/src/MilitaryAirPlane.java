public class MilitaryAirPlane extends AirPlane {

    String Type;
    String Weapon;

    public MilitaryAirPlane(String Country, String Name, String Model, String Length, String Weight, String FuselageMaterial, String EnginePower, String Type, String Weapon) {

        MilitaryAirPlane.Country = Country;
        MilitaryAirPlane.Name = Name;
        MilitaryAirPlane.Model = Model;
        MilitaryAirPlane.Length = Length;
        MilitaryAirPlane.Weight = Weight;
        MilitaryAirPlane.FuselageMaterial = FuselageMaterial;
        MilitaryAirPlane.EnginePower = EnginePower;
        this.Type = Type;
        this.Weapon = Weapon;
        setCountOfObjects(getCountOfObjects()+1);
    }

    String getAllInfo() {
        return MilitaryAirPlane.Country + ";" + MilitaryAirPlane.Name + ";" + MilitaryAirPlane.Model + ";" + MilitaryAirPlane.Length + ";" + MilitaryAirPlane.Weight + ";"
                + MilitaryAirPlane.FuselageMaterial + ";" + MilitaryAirPlane.EnginePower + ";" + Type + ";" + Weapon + ";";
    }

}
