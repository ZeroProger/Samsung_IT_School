public class SportAirPlane extends AirPlane {

    String countOfPilots;

    public SportAirPlane(String Country, String Name, String Model, String Length, String Weight, String FuselageMaterial, String EnginePower, String countOfPilots) {

        SportAirPlane.Country = Country;
        SportAirPlane.Name = Name;
        SportAirPlane.Model = Model;
        SportAirPlane.Length = Length;
        SportAirPlane.Weight = Weight;
        SportAirPlane.FuselageMaterial = FuselageMaterial;
        SportAirPlane.EnginePower = EnginePower;
        this.countOfPilots = countOfPilots;
        setCountOfObjects(getCountOfObjects()+1);
    }

    String getAllInfo() {
        return SportAirPlane.Country + ";" + SportAirPlane.Name + ";" + SportAirPlane.Model + ";" + SportAirPlane.Length + ";" + SportAirPlane.Weight + ";"
                + SportAirPlane.FuselageMaterial + ";" + SportAirPlane.EnginePower + ";" + countOfPilots + ";";
    }


}
