

/*
        Разработать базовый класс "Самолёт". Базовый класс имеет следующие обязательные поля:
        - Страна происхождения
        - Название
        - Модель
        - Длинна
        - Вес
        - Осносвной материал фюзеляжа
        - Мощьность двигателя

        Данный класс имеет метод getAllInfo, который возвращает значения всех полей класса разделённых символом ";", в виде одной строки.
        Базовый класс должен иметь статическое final поле countOfObjects, доступ к которому осуществляется с помощью гетера и сетера.
        Это поле всегда отображает количество созданных объектов, являющихся наследниками класса "Самолёт" (подумайте над конструктором).

        От базового класса создать три дополнительных класса, наследника "Самолёт": Спортивный самолёт, Пассажирский самолёт, Военный самолёт.

        Класс "Спортивный самолёт" имеет одно поле: количество пилотов.
        Переписать метод getAllInfo, чтобы он возвращал информацию по всем полям класса в ввиде одной строки.

        Класс "Пассажирский самолёт" должен иметь следующие поля:
        - Кол-во двигателей
        - Кол-во пассажиров

        Также класс должен иметь конструктор, в который будут передаваться поля "Кол-во двигателей" и "Кол-во пассажиров".
        Переписать метод getAllInfo, чтобы он возвращал информацию по всем полям класса в ввиде одной строки.

        Класс "Военный самолёт" должен иметь иметь следующие поля:
        - тип
        - Вооружение
        Переписать метод getAllInfo, чтобы он возвращал информацию по всем полям класса в ввиде одной строки.

        В основном методе main программы, создать по три объекта классов "Спортивный самолёт", "Пассажирский самолёт" и "Военный самолёт", заполнить их реальными данными.
        В результате выполнения программы вывести на экран информацио о каждом самолёте в ввиде девяти строк
        Поля из ТЗ (которые описаны на русском языке) должны именоваться по английски, понятно.
*/

public class Main {

    public static void main(String[] args) {

        SportAirPlane sport1 = new SportAirPlane("Russia", "Sport Air Plane", "Су-26", "6,83 м", "680 кг",
                                                "Композитный материал", "360 л.с", "1 пилот");
        System.out.println(sport1.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        SportAirPlane sport2 = new SportAirPlane("Russia", "Sport Air Plane", "Як-52", "7,68 м", "1040 кг",
                                                "Композитный материал", "360 л.с", "2 пилота");
        System.out.println(sport2.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        SportAirPlane sport3 = new SportAirPlane("USA", "Cessna 172 Skyhawk", "172D", "8,28 м", "736 кг",
                                                "Композитный материал", "175 л.с", "1 пилот");
        System.out.println(sport3.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        PassengerAirPlane passenger1 = new PassengerAirPlane("Russia", "Boeing", "757", "54,47 м", "64 340 кг",
                                                "Дюралюминий", "189,4 кН", "2 двигателя", "280 пассажиров");
        System.out.println(passenger1.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        PassengerAirPlane passenger2 = new PassengerAirPlane("France", "Airbus", "A318-100", "31,44 м", "39 500 кг",
                                                            "Дюралюминий", "101 кН", "2 двигателя", "117 пассажиров");
        System.out.println(passenger2.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        PassengerAirPlane passenger3 = new PassengerAirPlane("Russia", "Boeing Dreamliner", "787-9", "63 м", "126 000 кг",
                                                            "Дюралюминий", "340 кН", "2 двигателя", "290 пассажиров");
        System.out.println(passenger3.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        MilitaryAirPlane military1 = new MilitaryAirPlane("Russia", "Медведь", "ТУ-95", "46,17 м", "83 100 кг",
                                                        "Алюминиевые и магниевы сплавы", "4x12000 л.с", "Дальний бомбардировщик",
                                                        "6xAM23 23мм калибра и до 9000 кг свободнопадающих бомб");
        System.out.println(military1.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        MilitaryAirPlane military2 = new MilitaryAirPlane("China", "Shenjang", "FC-31", "16,9 м", "17600 кг",
                                                        "Алюминиевые и магниевы сплавы", "100 кН", "Истребитель", "4 ракеты PL-12");
        System.out.println(military2.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

        MilitaryAirPlane military3 = new MilitaryAirPlane("Russia", "Сухой", "Т-60", "40 м", "32000 кг",
                                                        "Алюминиевые и магниевы сплавы", "2х 23500 кгс", "Сверхзвуковой бомбардировщик",
                                                        "крылатые ракеты Х-55МС до 6 штук и 20000 кг бомб");
        System.out.println(military3.getAllInfo() + AirPlane.getCountOfObjects() + " objects");

    }

}
