public class PassengerAirPlane extends AirPlane {

    String countOfEngine;
    String countOfPassenger;

    public  PassengerAirPlane(String Country, String Name, String Model, String Length, String Weight, String FuselageMaterial, String EnginePower, String countOfEngine, String countOfPassenger) {

        PassengerAirPlane.Country = Country;
        PassengerAirPlane.Name = Name;
        PassengerAirPlane.Model = Model;
        PassengerAirPlane.Length = Length;
        PassengerAirPlane.Weight = Weight;
        PassengerAirPlane.FuselageMaterial = FuselageMaterial;
        PassengerAirPlane.EnginePower = EnginePower;
        this.countOfEngine = countOfEngine;
        this.countOfPassenger = countOfPassenger;
        setCountOfObjects(getCountOfObjects()+1);
    }

    String getAllInfo() {
        return PassengerAirPlane.Country + ";" + PassengerAirPlane.Name + ";" + PassengerAirPlane.Model + ";" + PassengerAirPlane.Length + ";" + PassengerAirPlane.Weight + ";"
                + PassengerAirPlane.FuselageMaterial + ";" + PassengerAirPlane.EnginePower + ";" + countOfEngine + ";" + countOfPassenger + ";";
    }

}
