public class AirPlane {

    private static int countOfObjects = 0;

    public static String Country;
    public static String Name;
    public static String Model;
    public static String Length;
    public static String Weight;
    public static String FuselageMaterial;
    public static String EnginePower;

    public static int getCountOfObjects() {
        return countOfObjects;
    }

    public static int setCountOfObjects(int n) {
        countOfObjects = n;
        return countOfObjects;
    }

    String getAllInfo() {
        return Country + ";" + Name + ";" + Model + ";" + Length + ";" + Weight + ";" + FuselageMaterial + ";" + EnginePower + ";";
    }

}
